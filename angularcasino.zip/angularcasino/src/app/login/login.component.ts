import { Component } from '@angular/core';
import { FormControl, FormGroup, FormGroupName, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { GamesserviceService } from '../services/gamesservice.service';
import { LoadingComponent } from "../loading/loading.component";


@Component({
  selector: 'app-login',
  standalone:true,
  imports: [ReactiveFormsModule, LoadingComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  
  isloading:boolean=false;
  errortext:string='';
  formlogin:FormGroup;
  submitted:boolean=false;
  logintext:string='';
  constructor(private auth:AuthService,private router:Router,private games:GamesserviceService){
    this.formlogin= new FormGroup({
      Username:new FormControl('',[Validators.required,Validators.maxLength(100),Validators.minLength(6)]),
      password:new FormControl('',[Validators.required,Validators.maxLength(100),Validators.minLength(8),Validators.pattern(/^(?=.*\d).+$/)])
    })
  }
  
  login(){
    this.errortext=''
    this.submitted=true;

    if(this.formlogin.valid){
      const { Username: user, password: pas } = this.formlogin.value;
      this.auth.login(user,pas).subscribe({
        next:(res)=>{
          this.router.navigate(["/profile"])
          this.logintext=res
          this.useridget()
          this.loader()
        },
        error:(res)=>{
          this.errortext = res.error || 'An unexpected error occurred';
        }
      })
    }else{
      this.errortext ='Fill out form Correctly';
    }
  }

  useridget(){
    this.auth.isloggedin().subscribe({
      next:((res:any)=>{
        this.games.setUserId(res.id)
      }),
      error:((res:any)=>{
        this.errortext="there occured some problem while getting in id"
      })
    })
  }

  loader(){
    this.games.loader.subscribe((bool:boolean)=>{
      this.isloading=bool
    })
  }
}
