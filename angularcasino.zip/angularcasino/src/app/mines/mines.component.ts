import { CommonModule } from '@angular/common';
import { Component} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { GamesserviceService } from '../services/gamesservice.service';
import { MinesService } from '../services/mines.service';
import { Howl } from 'howler';


@Component({
  selector: 'app-mines',
  standalone: true,
  imports: [RouterModule, CommonModule, ReactiveFormsModule],
  templateUrl: './mines.component.html',
  styleUrls: ['./mines.component.css']
})
export class MinesComponent {

  public  inputValue !: string;

  public submitted:boolean=false;

  public errortext:any=''

  public numb: number[] = [];

  public inside:string='<i class="fa-solid fa-crown"></i>'

  public gem:string='<i class="fa-solid fa-gem text-yellow-400"></i>'

  public bomb:string='<i class="fa-solid fa-bomb text-red-400"></i>'

  public minesnumberid:number=0

  public minesarea:number[]=[1,3,5,10,15]

  public defeatmines:any[]=[]

  public winnings:any

  public moneyamount:FormGroup;

  public buttonsContent: string[] = [];


  constructor(private games:GamesserviceService,private mines:MinesService) {
    this.moneyamount = new FormGroup({
      amount: new  FormControl('',[Validators.min(1),Validators.required,Validators.pattern(/^\d+(\.\d{1,2})?$/)])
    })
    for (let i = 1; i <= 25; i++) {
      this.buttonsContent.push('')
      this.buttonsContent.fill(this.inside);
      this.numb.push(i);
    }
    this.getid()

  }


  public sounds: { [key: string]: Howl } = {
    click: new Howl({ src: ['assets/sounds/button-305770.mp3'] }),
    explosion: new Howl({ src: ['assets/sounds/explosion-42132.mp3'] }),
    moneysound: new Howl({ src: ['assets/sounds/MONEY SOUND EFFECT !!.mp3'] }),
    victory: new Howl({ src: ['assets/sounds/victorymale-version-230553.mp3'] })
  };
  

  public userid:string | null =null
  getid(){
    this.userid=this.games.getUserId()
  }
  minesnumber(id:number){
    this.minesnumberid=id;    
  }
  chosenmine(id: number,idx: number) {

    this.minesnumberid=0
    this.errortext = '';
    this.mines.revealmine(this.userid, id).subscribe({
      next: (res: any) => {
        this.winnings = res.winnings;

        const icon = this.winnings ? this.gem : this.bomb;

        if(this.winnings){
          this.sounds['click'].play();
        }else{
          this.sounds['explosion'].play()
          this.submitted=false
         setTimeout(() => {
          this.buttonsContent.fill(this.inside);
         }, 2000);
        }
        this.buttonsContent[idx] = icon;

      },
      error: (err: any) => {
        this.errortext = err.error;
      }
    });
  }
  startGame(){

    this.errortext=''
    if(this.submitted==false){
      const fuli=this.moneyamount.get('amount')?.value
      this.mines.minestart(this.userid,this.minesnumberid,fuli,5).subscribe({
      next:((res:any)=>{
        this.buttonsContent.fill(this.inside);
        this.defeatmines=res.mines.$values
        this.submitted=true
      }),
      error:((err:any)=>{
        this.errortext=err.error
      })
    })

      this.inputValue = '';
  }
  else{
    this.sounds['moneysound'].play()
    this.mines.cashoutmoney(this.userid).subscribe({
      next:((res:any)=>{
        this.buttonsContent.fill(this.inside);
        this.winnings=''
        this.submitted=false
        
      }),
      error:((res)=>{
        this.errortext=res.error
      })
    })
  }
  }


}


