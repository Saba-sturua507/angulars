import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { GamesserviceService } from '../services/gamesservice.service';
import {
  gethorsewithid,
  horse,
  horsedabruneba,
  HorsesService,
} from '../services/horses.service';
import { min } from 'rxjs';

@Component({
  selector: 'app-horses',
  imports: [RouterModule,CommonModule,ReactiveFormsModule ],
  templateUrl: './horses.component.html',
  styleUrl: './horses.component.css',
})
export class HorsesComponent {

  public greatestime: number | undefined

  public submitted:boolean=false

  public timedata: (number | undefined)[] = [];

  public newtimedata:(number | undefined)[] = [];

  public timearrey: horse[] = [];

  public lowesttime: number | undefined;

  public wholeinfo!: horsedabruneba | undefined;

  public text!: string;

  public chosenhorse!: string;

  public userid: string | null = null;

  public wonornot!: boolean;

  public money: FormGroup;
  constructor(
    private games: GamesserviceService,
    private horsegame: HorsesService
  ) {
    this.money = new FormGroup({
      amount: new FormControl('', [Validators.min(1), Validators.required]),
    });
    this.gethorseswithcollrandnames();
    this.getid();
  }

  public horses: horse[] = [];

  gethorseswithcollrandnames() {
    this.horsegame.gethorses().subscribe({
      next: (res: gethorsewithid) => {
        this.horses = res.$values;
      },
    });
  }

  getid() {
    this.userid = this.games.getUserId();
  }

  chosehorse(name: string) {
    this.chosenhorse = name;
  }

startgame() {
  const fuli = this.money.get('amount')?.value;
  this.horsegame
    .playwithhorses(this.chosenhorse, fuli, this.userid)
    .subscribe({
      next: (res: horsedabruneba) => {
        this.submitted = true;
        this.wholeinfo = res;

        if (res.userWon) {
          this.text = 'YOU WON';
        } else {
          this.text = 'YOU LOST';
        }

        this.timearrey = this.horses.map((horse) => {
          const Data = this.wholeinfo?.raceTimes.$values.find(
            (timeData) => timeData.horse === horse.name
          );
          return {
            ...horse,
            time: Data ? Data.time : undefined,
          };
        });



        this.timearrey.forEach((data) => {
          this.timedata.push(data.time);
        });



        this.newtimedata = this.timedata
          .filter((data): data is number => data !== undefined)
          .map((data) => data * 5000);

        if (this.newtimedata.length === 0) {

          this.newtimedata = [13000]; 
        }

        this.greatestime = Math.max(...(this.newtimedata as number[]));

        this.lowesttime=Math.min(...(this.newtimedata as number[]))

        setTimeout(() => {
          this.submitted = false;
          this.timedata=[]
          this.newtimedata=[]
        }, this.greatestime ? Math.floor(this.greatestime) : 1000);
      },
    });
}


}
