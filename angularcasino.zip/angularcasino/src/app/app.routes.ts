import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ProfileComponent } from './profile/profile.component';
import { LoginComponent } from './login/login.component';
import { CoinflipComponent } from './coinflip/coinflip.component';
import { RegisterComponent } from './register/register.component';
import { loginguardGuard } from './casinoguards/loginguard.guard';
import { MinesComponent } from './mines/mines.component';
import { HorsesComponent } from './horses/horses.component';
import { TowersComponent } from './towers/towers.component';

export const routes: Routes = [
  {path:"", component: HomeComponent },
  {path:"login",component:LoginComponent},
  {path:"coinflip",component:CoinflipComponent,canActivate:[loginguardGuard]},
  {path:"register",component:RegisterComponent},
  {path:"profile",component:ProfileComponent,canActivate:[loginguardGuard]},
  {path:"mines",component:MinesComponent , canActivate:[loginguardGuard]},
  {path:"horses",component:HorsesComponent,canActivate:[loginguardGuard]},
  {path: "towers",component:TowersComponent,canActivate:[loginguardGuard]},
  {path:"**",component:NotFoundComponent},
];

