import { Attribute, Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { AuthService, ProfileInfo } from '../services/auth.service';
import { CookieService } from 'ngx-cookie-service';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ChangeDetectorRef } from '@angular/core';
import { GamesserviceService } from '../services/gamesservice.service';
import { LoadingComponent } from "../loading/loading.component";

@Component({
  selector: 'app-profile',
  imports: [RouterModule, FormsModule, ReactiveFormsModule, LoadingComponent],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  errortext:string='';
  userId: number = 0;
  casinobalance:number=0;
  profileinfo: ProfileInfo = {
    username: '',
    profilepicture: '',
    email: '',
    wholebalance: 0,
    age: 0,
    number: 0
  };

  moneydeposit: FormGroup;
  moneywidtdraw:FormGroup;
  profileimg: string = 'https://wallpapers.com/images/hd/cool-profile-picture-o6xweez7rh4347gx.jpg';

  sounds: { [key: string]: Howl } ={
    moneysound: new Howl({ src: ['assets/sounds/MONEY SOUND EFFECT !!.mp3'] }),
}
  constructor(private auth: AuthService, private router: Router,private cdr: ChangeDetectorRef,private games:GamesserviceService,private cook:CookieService) {
    this.moneydeposit = new FormGroup({
      amountmoney: new FormControl('', [Validators.required, Validators.min(1)])
    });
    this.moneywidtdraw= new FormGroup({
      amountmoney:new FormControl('',[Validators.required,Validators.min(1)])
    })
  }

  ngOnInit(): void { 
      this.isloggin();
      this.loader();
  }


  isloggin() {
    this.errortext='';
    this.auth.isloggedin().subscribe({
      next: (res: any) => {
        this.userId = res.id;
        this.profileinfo = {
          username: res.userName,
          profilepicture: this.profileimg,
          email: res.email,
          wholebalance: res.balance,
          age: res.age,
          number: res.numbere
        };
        this.casinomoney()
      },
      error: (err: any) => {
        this.errortext=err.error
      }
    });
  }

linkcasino(){
  this.errortext='';
  this.auth.casinolink(this.userId).subscribe({
    next:((res)=>{
      this.casinomoney()
    }),
    error:(res=>{
      this.errortext=res.error
    })
  })
}

casinomoney() {
  this.auth.some(this.userId).subscribe({
    next: (res:any) => {
      this.casinobalance=res.casinoBalance;
    },
    error:((res:any)=>{
      this.errortext=res.error;
    })
  });
}


  deposit() {
    this.sounds['moneysound'].play()
    this.errortext='';
    const moneyvalue = this.moneydeposit.value.amountmoney;
    this.auth.depositsome(this.userId, moneyvalue).subscribe({
      next: (res) => {
        this.isloggin()
        this.moneydeposit.reset();
        this.casinomoney()
        setTimeout(() => this.casinomoney(), 100);

      },
      error:((res)=>{
        this.moneydeposit.reset();
        this.errortext=res.error || 'Unexpected error occured'
      })
    });
  }
  
  withdraw() { 
    this.sounds['moneysound'].play()
    this.errortext='';
    const moneyvalue = this.moneywidtdraw.value.amountmoney;
    this.auth.withdrawsome(this.userId, moneyvalue).subscribe({
      next: () => {
        this.isloggin();
        this.moneywidtdraw.reset();
        this.casinomoney()
        setTimeout(() => this.casinomoney(), 100);
      },
      error:((res)=>{
        this.moneywidtdraw.reset();
        this.errortext=res.error || 'Unexpected error occured'
      })
    });
  }
  public isloading:boolean=false;
  loader(){
    this.games.loader.subscribe((bool:boolean)=>{
      this.isloading=bool
    })
  }
}