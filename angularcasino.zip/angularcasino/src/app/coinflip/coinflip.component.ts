import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GamesserviceService } from '../services/gamesservice.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-coinflip',
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './coinflip.component.html',
  styleUrl: './coinflip.component.css'
})
export class CoinflipComponent {
  public errortext :string =''
  public userid:string | null =null;
  public submitted:boolean=false;
  public winningside:string='Heads';
  public side :any='';
  public text:string=''
  public usermoney:FormGroup;
  public win!:boolean ;
  constructor(private actr:ActivatedRoute,private games:GamesserviceService){
    this.usermoney = new FormGroup({
      money : new  FormControl('',[Validators.min(1),Validators.required,Validators.pattern(/^\d+(\.\d{1,2})?$/)])
    })

    this.getid()
  }


  head(){
    this.errortext=''
    this.side='Heads'
  }
  tail(){
    this.errortext=''
    this.side='Tails'
  }

  flipcoin() {
    this.text=''
    if (this.usermoney.valid) {
      const money = this.usermoney.get('money')?.value;
      this.submitted=true
      this.games.flip(this.userid, money, this.side).subscribe({
        next: (res: any) => {
          setTimeout(() => {
            this.winningside=res
            if (res !== this.side) {
              this.text = 'YOU LOST';
              this.win = false;
            } else {
              this.text = 'YOU WON';
              this.win = true;
            }
          }, 2000); 
          
          
        },
        error: (res: any) => {
          this.errortext = res.error;
        }
      });
    } else {
      this.errortext = 'write correct amount of money';
    }
    setTimeout(() => {
      this.submitted=false;
    }, 3500);
    
  }

  
  getid(){
    this.userid=this.games.getUserId()
  }
}
