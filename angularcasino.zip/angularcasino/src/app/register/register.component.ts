import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { LoadingComponent } from "../loading/loading.component";
import { GamesserviceService } from '../services/gamesservice.service';
@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule, CommonModule, LoadingComponent],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  errortext:string='';
  forminfo:FormGroup;
  submitted :boolean =false;
  constructor(private auth:AuthService,private router:Router,private games:GamesserviceService){
    this.forminfo= new FormGroup({
      userName : new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(100)]),
      number: new FormControl('',Validators.max(140000)),
      email: new FormControl('',[Validators.required,Validators.email]),
      age:new FormControl('',[Validators.required,Validators.max(100),Validators.min(18)]),
      pas:new FormControl('',[Validators.required,Validators.minLength(8),Validators.maxLength(100),Validators.pattern(/^(?=.*\d).+$/)])
    })
  }
  
  register(){
    this.submitted=true;
    
    if(this.forminfo.valid){
      const { userName,number, email, age, pas } = this.forminfo.value;
      this.auth.register(userName,number,email,age,pas).subscribe({
        next:(res)=>{
          this.router.navigate(['/login']);
          this.loader()
        },
        error:(res)=>{
          this.errortext = res.error || 'An unexpected error occurred';
        }
      })
    }else {
      this.errortext ='Form is invalid';
    }
  }
  isloading:boolean=false;
  
  loader(){
    this.games.loader.subscribe((bool:boolean)=>{
      this.isloading=bool
    })
  }
}
