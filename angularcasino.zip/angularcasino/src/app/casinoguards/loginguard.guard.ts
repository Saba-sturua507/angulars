import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { GamesserviceService } from '../services/gamesservice.service';

export const loginguardGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const games = inject(GamesserviceService);
  const router = inject(Router);

  const userId = games.getUserId();

  if (userId === null || userId === '0') {
    router.navigate(['/login']); 
    return false;
  }

  return true;
};