import { Component } from '@angular/core';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { RouterModule } from '@angular/router';
import { GamesserviceService } from '../services/gamesservice.service';
import { TowersService, Winnings } from '../services/towers.service';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-towers',
  imports: [RouterModule, ReactiveFormsModule, CommonModule],
  templateUrl: './towers.component.html',
  styleUrl: './towers.component.css',
})
export class TowersComponent {

  public inputvalue!:string

  public diamond: string =
    '<i class="fa-solid fa-diamond text-blue-800"></i> CORRECT!';

  public landminn: string =
    '<i class="fa-solid fa-star text-red-500"></i> YOU LOST';

  public totalwinnings!: string;

  public startgame: string = 'START GAME';

  public submitted: boolean = false;

  public tower: string =
    '<i class="fa-solid fa-tower-observation"></i> CLICK ME!!';

  public content: string[][] = [];

  public normal: number[][] = [];

  public easyandhard: number[][] = [];

  public difi!: string;

  public playersid!: string | null;

  public money: FormGroup;

  public difficulty: string[] = ['easy', 'normal', 'hard'];

  public numb: number[][] = [];


    public sounds: { [key: string]: Howl } = {
      click: new Howl({ src: ['assets/sounds/button-305770.mp3'] }),
      explosion: new Howl({ src: ['assets/sounds/explosion-42132.mp3'] }),
      moneysound: new Howl({ src: ['assets/sounds/MONEY SOUND EFFECT !!.mp3'] }),
      victory: new Howl({ src: ['assets/sounds/victorymale-version-230553.mp3'] })
    }

  constructor(
    private games: GamesserviceService,
    private towers: TowersService
  ) {
    this.getid();
    this.money = new FormGroup({
      amount: new FormControl('', [Validators.required, Validators.min(1)]),
    });
    for (let j = 1; j <= 3; j++) {
      const row: number[] = [];
      const conrow: string[] = [];
      for (let i = 1; i <= 8; i++) {
        conrow.push('');
        conrow.fill(this.tower);
        row.push(i);
      }
      this.content.push(conrow);
      this.easyandhard.push(row);
    }
    for (let j = 1; j <= 2; j++) {
      const row: number[] = [];
      for (let i = 1; i <= 8; i++) {
        row.push(i);
      }
      this.normal.push(row);
    }
    this.numb = this.easyandhard;
  }
  getid() {
    this.playersid = this.games.getUserId();
  }

  chosedif(dif: string) {
    this.difi = dif;
    if (dif === 'normal') {
      this.numb = this.normal;
    } else {
      this.numb = this.easyandhard;
    }
  }

  chosemine(row: number, col: number) {
    this.towers.towerminereveal(this.playersid, col + 1, row + 1).subscribe({
      next: (res: Winnings) => {
        this.totalwinnings = res.winnings;
        if (this.totalwinnings) {
          this.sounds['click'].play();
          this.content[row][col] = this.diamond;
        } else {
          this.sounds['explosion'].play()
          this.totalwinnings=''
          this.content[row][col] = this.landminn;
          this.startgame = 'START GAME';
          this.submitted = false;
          setTimeout(() => {
          this.content = this.content.map((row) => row.map(() => this.tower));
          }, 2000);
        }
      },
    });
  }

  playtowers() {
    const fuli = this.money.get('amount')?.value;

    if (this.submitted === false) {
      this.towers.startthegame(this.playersid, fuli, this.difi).subscribe({
        next: () => {
          this.totalwinnings=''
          this.inputvalue=''
          this.startgame = 'CASHOUT';
          this.submitted = true;
          this.content = this.content.map((row) => row.map(() => this.tower));
        },
      });
    } else {
      this.sounds['moneysound'].play()
      this.towers.cashout(this.playersid).subscribe({
        next: () => {
          this.inputvalue=''
          this.startgame = 'START GAME';
          this.submitted = false;
        },
      });
    }
  }
}
