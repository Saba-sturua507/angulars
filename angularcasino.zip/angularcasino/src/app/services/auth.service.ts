import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment.development';
import { CookieService } from 'ngx-cookie-service';

export interface User {
  userName: string;
  number:number;
  email: string;
  age: number;
  pas: string;
}

export interface Userlogin{
  userName:string;
  password:string;
}

export interface ProfileInfo {
  username: string;
  profilepicture:string;
  email: string;
  wholebalance: number;
  age:number;
  number:number;
}


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public loggin:boolean=false;
  private userRegisterUrl: string = environment.registeruseurl;

  constructor(private http: HttpClient,private cook:CookieService){}

  register(userName: string,number:number, email: string, age: number, pas: string) {
    const user: User = {
      userName:userName,
      number:number,
      email:email,
      age:age,
      pas:pas,
    };
    return this.http.post(this.userRegisterUrl, user,{ responseType: 'text' });
  }
  private userloginurl:string=environment.loginuseurl;
  login(user:string,pas:string){
    this.loggin=true;
    const userlog:Userlogin={
      userName:user,
      password:pas
    }
    return this.http.post(this.userloginurl,null, {
      params: { user, pas},
      responseType: 'text'   
    })
  }
  private currentuser:string=environment.currentuser;

  isloggedin(){
    return this.http.get(this.currentuser)
  }

  private casinomainlink=environment.casinomainlink;

  casinolink(userId:number){
    return this.http.post(`${this.casinomainlink}/link`,null,{
      params:{userId},
      responseType:'text'
    })
  }



  some(id:number) {
    return this.http.get(`${this.casinomainlink}/user/${id}`);
  }
  depositsome(id: number, amount: number) {
    return this.http.post(`${this.casinomainlink}/deposit/${id}/${amount}`, null, {
      responseType: 'text'
    });
  }
  
  withdrawsome(id: number, amount: number) {
    return this.http.post(`${this.casinomainlink}/withdraw/${id}/${amount}`, null, {
      responseType: 'text'
    });
  }

}
