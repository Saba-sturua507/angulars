import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { environment } from '../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class GamesserviceService {

  constructor(private http:HttpClient) { }
  private key :string ='userid';

  setUserId(id: number) {
    sessionStorage.setItem(this.key, id.toString());
  }

  getUserId(): string | null {
    return sessionStorage.getItem(this.key);
  }

  public loader: BehaviorSubject<boolean> = new BehaviorSubject(false)

  startloading(){
    return this.loader.next(true)
  }

  stoploading(){
    return this.loader.next(false)
  }

  private flipcoin=environment.flipacoin;
  flip(id :string | null,money:number,side:any){
    return this.http.post(`${this.flipcoin}/${id}/${money}/${side}`,{},{
      responseType:'text',
    })
  }
}
