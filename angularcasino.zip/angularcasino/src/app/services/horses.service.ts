import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';


export interface gethorsewithid{
  $id:number
  $values:horse[]
}

export interface horse{
  $id:string
  name:string
  odds:number
  color:string
   time?: number;
}


export interface horsedabruneba{
  $id:string
  winningHorse:string
  userWon:boolean
  winnings:number
  raceTimes:horsedabrunebawithid
}

export interface horsedabrunebawithid{
  $id:string
  $values:horsetime[]
}

export interface  horsetime{
  $id:string
  horse:string
  time:number
}

@Injectable({
  providedIn: 'root'
})
export class HorsesService {

  constructor(private http:HttpClient){}
  private horseurl=environment.horses
  gethorses(){
    return this.http.get<gethorsewithid>(`${this.horseurl}/horses`)
  }

  playwithhorses(HorseName:string,bet:number,user:string | null){
    const params = new HttpParams({
    fromObject: {
    HorseName: HorseName,
    BetAmount: bet.toString(),
    UserId: user ?? ''
    }
    });

    return this.http.post <horsedabruneba>(`${this.horseurl}/race`,null,{params})
  }
}
