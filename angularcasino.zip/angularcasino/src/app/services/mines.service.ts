import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';


@Injectable({
  providedIn: 'root'
})
export class MinesService {

  constructor(private http:HttpClient) { }
  
  private minesurl=environment.mine

  minestart(userId:string | null,minesCount:number,betAmount:number,gridSize:number){
    const params = new HttpParams()
  .set('userId', userId ?? '')
  .set('minesCount', minesCount.toString())
  .set('betAmount', betAmount.toString())
  .set('gridSize', gridSize.toString());
  return this.http.post(`${this.minesurl}/start`, null, { params });
  
  }
  revealmine(userId:string | null,index:number){
    return this.http.post(`${this.minesurl}/reveal?userId=${userId}&cellIndex=${index}`,null)
  }
  cashoutmoney(id:string | null){
    return this.http.post(`${this.minesurl}/cashout?userId=${id}`,null)
  }
}
