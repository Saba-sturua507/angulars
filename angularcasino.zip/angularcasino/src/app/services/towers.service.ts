import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { __param } from 'tslib';


export interface Winnings{
  winnings:string
}


@Injectable({
  providedIn: 'root'
})
export class TowersService {

  constructor(private http:HttpClient) { }
 
  private towerurl=environment.tower
  startthegame(id:string | null,betamount:number,difficulty:string){
    const params= new HttpParams()
    .set('userId' , id ?? '')
    .set('betAmount',betamount.toString())
    .set('difficulty', difficulty)
    return this.http.post(`${this.towerurl}start`,null,{params})
  }
  cashout(id:string | null){
    const  params= new HttpParams()
    .set('userId',id ?? '')
    return this.http.post(`${this.towerurl}cashout`,null,{params})
  }

  towerminereveal(id: string | null,floor : number,index: number){
    const params = new HttpParams()
    .set('userId',id ?? '')
    .set('floor',floor.toString())
    .set('bombIndex',index.toString())
    return this.http.post<Winnings>(`${this.towerurl}reveal`,null,{params})
  }
}
