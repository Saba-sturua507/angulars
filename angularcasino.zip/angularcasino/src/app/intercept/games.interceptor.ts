import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { GamesserviceService } from '../services/gamesservice.service';
import { finalize } from 'rxjs';

export const gamesInterceptor: HttpInterceptorFn = (req, next) => {

  const games=inject(GamesserviceService)

  games.startloading()

  return next(req).pipe(
    finalize(()=>{
      games.stoploading()
    })
  )
  
};
