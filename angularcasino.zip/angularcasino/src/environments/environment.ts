export const environment = {
    production:false,
    registeruseurl: 'http://localhost:5130/api/Login/register',
    loginuseurl:'http://localhost:5130/api/Login',
};
