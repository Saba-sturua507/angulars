export const environment = {
    production:true,
    registeruseurl: 'http://localhost:5130/api/Login/register',
    loginuseurl:'http://localhost:5130/api/Login/login',
    currentuser:'http://localhost:5130/api/Login/current-user',
    casinomainlink:'http://localhost:5130/api/CasinoAcount',
    flipacoin:'http://localhost:5130/api/Flipacoin/flip',
    mine:'http://localhost:5130/api/Mine',
    horses:'http://localhost:5130/api/HorseRacing',
    tower:'http://localhost:5130/api/Tower/',
};
